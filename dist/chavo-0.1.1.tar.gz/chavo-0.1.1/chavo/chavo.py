__version__ = "0.1.1"

import sys
from .packages import *

class main:
	def __init__(self):
		if len(sys.argv) > 1:
			self.check_packages()
		else:
			print 'No function called, available packages:\n \toscar'

	def check_packages(self):
		if sys.argv[1] == 'oscar':
			Oscar(sys.argv[2:])