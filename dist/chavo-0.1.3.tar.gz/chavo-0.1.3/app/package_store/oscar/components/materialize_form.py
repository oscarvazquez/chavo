class m_form:
	def __init__(self):
		print 'm_form'