from oscar.oscar import Oscar
__all__ = ["Oscar"]