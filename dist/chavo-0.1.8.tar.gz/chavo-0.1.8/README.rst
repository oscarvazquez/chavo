To use this pip module and create a copy of a pylot project, go through the following steps

1. pylot new <new_project_name>
2. cd into the project and source the setup file
3. Run . setup
	Now you can start your development server like so:
4. python manage.py runserver
5. Enjoy! More details/features coming soon!